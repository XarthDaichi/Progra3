package people.window;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class View {
    private JLabel idLbl;
    private JTextField idTxt;
    private JLabel nameLbl;
    private JTextField nameTxt;
    private JPanel savingPanel;
    private JLabel genderLbl;
    private JRadioButton maleButton;
    private JRadioButton femaleButton;
    private JRadioButton nbButton;
    private JLabel maritalStatusLbl;
    private JComboBox maritalStatusCB;
    private JLabel hobbiesLbl;
    private JPanel genderPanel;
    private JPanel hobbiesPanel;
    private JCheckBox musicCheckBox;
    private JCheckBox moviesCheckBox;
    private JCheckBox sportsCheckBox;
    private JCheckBox videogamesCheckBox;
    private JCheckBox cookingCheckBox;
    private JCheckBox otherCheckBox;
    private JTextField otherTxt;
    private JButton saveButton;
    private JButton cancelButton;
    private JPanel buttonPanel;

    public View() {
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println(nameTxt.getText());
            }
        });
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        })
    }
    public JPanel getSavingPanel() {
        return savingPanel;
    }
}
